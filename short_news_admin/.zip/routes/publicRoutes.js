const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const News = require('../models/News');
const User = require('../models/User');
const Location = require('../models/Location'); // Add this import
const Report = require('../models/Report'); // Add report model
const Ad = require('../models/Ad'); // Add ad model

// Public API endpoint for Flutter app (no authentication required)
router.get('/api/public/news', async (req, res) => {
  try {
    let newsList;
    
    // Check if MongoDB is connected
    const isConnectedToMongoDB = req.app.locals.isConnectedToMongoDB;
    
    if (isConnectedToMongoDB) {
      // Fetch only active published news from MongoDB
      // Include news where isActive is true or not set (implicitly active)
      newsList = await News.find({ 
        $or: [{ isActive: true }, { isActive: { $exists: false } }]
      }).sort({ publishedAt: -1 });
    } else {
      // Use in-memory storage and filter for active news
      const allNews = req.app.locals.newsData || [];
      newsList = allNews
        .filter(news => news.isActive !== false) // Include news where isActive is true or undefined
        .sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt)); // Sort by publishedAt descending (newest first)
    }
    
    // Transform data for Flutter app
    const transformedNews = newsList.map(news => {
      const newsObj = news.toObject ? news.toObject() : news;
      return {
        id: newsObj._id,
        title: newsObj.title,
        content: newsObj.content,
        imageUrl: newsObj.thumbnailUrl || newsObj.mediaUrl || newsObj.imageUrl || '/images/placeholder.png',
        mediaUrl: newsObj.mediaUrl || newsObj.imageUrl || '/images/placeholder.png',
        mediaType: newsObj.mediaType || 'image',
        category: newsObj.category,
        location: newsObj.location,
        publishedAt: newsObj.publishedAt,
        likes: newsObj.likes || 0,
        dislikes: newsObj.dislikes || 0,
        comments: newsObj.comments || 0,
        author: newsObj.author,
        isRead: newsObj.isRead || false,
        // Include user interaction details
        userLikes: newsObj.userInteractions?.likes || [],
        userDislikes: newsObj.userInteractions?.dislikes || [],
        userComments: newsObj.userInteractions?.comments || []
      };
    });
    
    res.json(transformedNews);
  } catch (error) {
    console.error('Error fetching public news:', error);
    res.status(500).json({ error: 'Error fetching news' });
  }
});

// Public API endpoint for Flutter app with category filter (no authentication required)
router.get('/api/public/news/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    let newsList;
    
    // Check if MongoDB is connected
    const isConnectedToMongoDB = req.app.locals.isConnectedToMongoDB;
    
    if (isConnectedToMongoDB) {
      // Fetch only active published news from MongoDB with category filter
      // Include news where isActive is true or not set (implicitly active)
      newsList = await News.find({ 
        $and: [
          { category: category },
          { $or: [{ isActive: true }, { isActive: { $exists: false } }] }
        ]
      }).sort({ publishedAt: -1 });
    } else {
      // Use in-memory storage and filter for active news with category filter
      const allNews = req.app.locals.newsData || [];
      newsList = allNews
        .filter(news => news.isActive !== false && news.category === category)
        .sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt)); // Sort by publishedAt descending (newest first)
    }
    
    // Transform data for Flutter app
    const transformedNews = newsList.map(news => {
      const newsObj = news.toObject ? news.toObject() : news;
      return {
        id: newsObj._id,
        title: newsObj.title,
        content: newsObj.content,
        imageUrl: newsObj.thumbnailUrl || newsObj.mediaUrl || newsObj.imageUrl || '/images/placeholder.png',
        mediaUrl: newsObj.mediaUrl || newsObj.imageUrl || '/images/placeholder.png',
        mediaType: newsObj.mediaType || 'image',
        category: newsObj.category,
        location: newsObj.location,
        publishedAt: newsObj.publishedAt,
        likes: newsObj.likes || 0,
        dislikes: newsObj.dislikes || 0,
        comments: newsObj.comments || 0,
        author: newsObj.author,
        isRead: newsObj.isRead || false,
        // Include user interaction details
        userLikes: newsObj.userInteractions?.likes || [],
        userDislikes: newsObj.userInteractions?.dislikes || [],
        userComments: newsObj.userInteractions?.comments || []
      };
    });
    
    res.json(transformedNews);
  } catch (error) {
    console.error('Error fetching public news by category:', error);
    res.status(500).json({ error: 'Error fetching news by category' });
  }
});

// Public API endpoint for Flutter app with location filter (no authentication required)
router.get('/api/public/news/location/:location', async (req, res) => {
  try {
    const { location } = req.params;
    let newsList;
    
    // Check if MongoDB is connected
    const isConnectedToMongoDB = req.app.locals.isConnectedToMongoDB;
    
    if (isConnectedToMongoDB) {
      // Fetch only active published news from MongoDB with location filter
      // Include news where isActive is true or not set (implicitly active)
      newsList = await News.find({ 
        $and: [
          { location: location },
          { $or: [{ isActive: true }, { isActive: { $exists: false } }] }
        ]
      }).sort({ publishedAt: -1 });
    } else {
      // Use in-memory storage and filter for active news with location filter
      const allNews = req.app.locals.newsData || [];
      newsList = allNews
        .filter(news => news.isActive !== false && news.location === location)
        .sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt)); // Sort by publishedAt descending (newest first)
    }
    
    // Transform data for Flutter app
    const transformedNews = newsList.map(news => {
      const newsObj = news.toObject ? news.toObject() : news;
      return {
        id: newsObj._id,
        title: newsObj.title,
        content: newsObj.content,
        imageUrl: newsObj.thumbnailUrl || newsObj.mediaUrl || newsObj.imageUrl || '/images/placeholder.png',
        mediaUrl: newsObj.mediaUrl || newsObj.imageUrl || '/images/placeholder.png',
        mediaType: newsObj.mediaType || 'image',
        category: newsObj.category,
        location: newsObj.location,
        publishedAt: newsObj.publishedAt,
        likes: newsObj.likes || 0,
        dislikes: newsObj.dislikes || 0,
        comments: newsObj.comments || 0,
        author: newsObj.author,
        isRead: newsObj.isRead || false,
        // Include user interaction details
        userLikes: newsObj.userInteractions?.likes || [],
        userDislikes: newsObj.userInteractions?.dislikes || [],
        userComments: newsObj.userInteractions?.comments || []
      };
    });
    
    res.json(transformedNews);
  } catch (error) {
    console.error('Error fetching public news by location:', error);
    res.status(500).json({ error: 'Error fetching news by location' });
  }
});

// New endpoint for user interactions (like, dislike, comment) with Google authentication
router.post('/api/public/news/:id/interact', async (req, res) => {
  try {
    const { id } = req.params;
    const { action, userId, userToken, commentText } = req.body;
    
    // Verify authentication token by calling the middleware directly
    let userInfo = null;
    try {
      // Create a mock request object
      const mockReq = { body: { userId, userToken } };
      
      // Create a promise to handle the async middleware
      await new Promise((resolve, reject) => {
        // Call the verifyGoogleToken middleware
        req.app.locals.verifyGoogleToken(mockReq, null, (err) => {
          if (err) {
            reject(err);
          } else {
            resolve();
          }
        });
      });
      
      // If verification is successful, extract user info
      const User = require('../models/User');
      const user = await User.findById(userId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // For Google users, extract info from the token
      if (user.googleId) {
        const client = req.app.locals.googleAuthClient;
        const ticket = await client.verifyIdToken({
          idToken: userToken,
          audience: process.env.GOOGLE_CLIENT_ID,
        });
        
        const payload = ticket.getPayload();
        userInfo = {
          userId: payload['sub'],
          userName: payload['name'] || 'User',
          userEmail: payload['email'] || 'user@example.com',
          photoUrl: payload['picture'] || null
        };
        
        // Update user info in case it changed
        user.displayName = userInfo.userName;
        user.email = userInfo.userEmail;
        user.photoUrl = userInfo.photoUrl;
        user.lastLogin = new Date();
        await user.save();
      } 
      // For mobile users, use the user data from database
      else if (user.mobileNumber) {
        userInfo = {
          userId: user._id,
          userName: user.displayName,
          userEmail: user.email,
          photoUrl: user.photoUrl
        };
        
        // Update last login time
        user.lastLogin = new Date();
        await user.save();
      }
    } catch (authError) {
      return res.status(401).json({ error: authError.message || 'Authentication required' });
    }
    
    // Validate action
    if (!['like', 'dislike', 'comment', 'unlike', 'undislike'].includes(action)) {
      return res.status(400).json({ error: 'Invalid action' });
    }
    
    // Check if MongoDB is connected by trying to access the connection
    const isConnectedToMongoDB = mongoose.connection.readyState === 1;
    
    let news;
    if (isConnectedToMongoDB) {
      // Find the news item in MongoDB
      news = await News.findById(id);
      if (!news) {
        return res.status(404).json({ error: 'News not found' });
      }
      
      // Create or update user in database
      let user = await User.findOne({ googleId: userInfo.userId }) || await User.findById(userId);
      if (!user) {
        user = new User({
          googleId: userInfo.userId,
          displayName: userInfo.userName,
          email: userInfo.userEmail,
          photoUrl: userInfo.photoUrl
        });
      } else {
        // Update last login time
        user.lastLogin = new Date();
        // Update user info in case it changed
        user.displayName = userInfo.userName;
        user.email = userInfo.userEmail;
        user.photoUrl = userInfo.photoUrl;
      }
      
      // Update the interaction count and store user details based on action
      switch (action) {
        case 'like':
          // Check if user has already disliked this news
          const existingDislikeIndex = news.userInteractions.dislikes.findIndex(dislike => dislike.userId === userInfo.userId);
          if (existingDislikeIndex !== -1) {
            // User is changing from dislike to like
            news.dislikes -= 1;
            news.userInteractions.dislikes.splice(existingDislikeIndex, 1);
            
            // Remove from user's dislikes
            const userDislikeIndex = user.interactions.dislikes.findIndex(dislikeId => String(dislikeId) === String(news._id));
            if (userDislikeIndex !== -1) {
              user.interactions.dislikes.splice(userDislikeIndex, 1);
            }
          }
          
          // Check if user has already liked this news
          const existingLikeIndex = news.userInteractions.likes.findIndex(like => like.userId === userInfo.userId);
          if (existingLikeIndex === -1) {
            // User is adding a new like
            news.likes += 1;
            news.userInteractions.likes.push({
              userId: userInfo.userId,
              userName: userInfo.userName,
              userEmail: userInfo.userEmail
            });
            
            // Add to user's interactions
            if (!user.interactions.likes.map(String).includes(String(news._id))) {
              user.interactions.likes.push(news._id);
            }
          } else {
            // User is removing their like (unliking)
            news.likes -= 1;
            news.userInteractions.likes.splice(existingLikeIndex, 1);
            
            // Remove from user's likes
            const userLikeIndex = user.interactions.likes.findIndex(likeId => String(likeId) === String(news._id));
            if (userLikeIndex !== -1) {
              user.interactions.likes.splice(userLikeIndex, 1);
            }
          }
          break;
          
        case 'dislike':
          // Check if user has already liked this news
          const existingLikeIndex2 = news.userInteractions.likes.findIndex(like => like.userId === userInfo.userId);
          if (existingLikeIndex2 !== -1) {
            // User is changing from like to dislike
            news.likes -= 1;
            news.userInteractions.likes.splice(existingLikeIndex2, 1);
            
            // Remove from user's likes
            const userLikeIndex = user.interactions.likes.findIndex(likeId => String(likeId) === String(news._id));
            if (userLikeIndex !== -1) {
              user.interactions.likes.splice(userLikeIndex, 1);
            }
          }
          
          // Check if user has already disliked this news
          const existingDislikeIndex2 = news.userInteractions.dislikes.findIndex(dislike => dislike.userId === userInfo.userId);
          if (existingDislikeIndex2 === -1) {
            // User is adding a new dislike
            news.dislikes += 1;
            news.userInteractions.dislikes.push({
              userId: userInfo.userId,
              userName: userInfo.userName,
              userEmail: userInfo.userEmail
            });
            
            // Add to user's interactions
            if (!user.interactions.dislikes.map(String).includes(String(news._id))) {
              user.interactions.dislikes.push(news._id);
            }
          } else {
            // User is removing their dislike (undisliking)
            news.dislikes -= 1;
            news.userInteractions.dislikes.splice(existingDislikeIndex2, 1);
            
            // Remove from user's dislikes
            const userDislikeIndex = user.interactions.dislikes.findIndex(dislikeId => String(dislikeId) === String(news._id));
            if (userDislikeIndex !== -1) {
              user.interactions.dislikes.splice(userDislikeIndex, 1);
            }
          }
          break;
          
        case 'unlike':
          // Handle explicit unlike action (same as removing a like)
          const likeIndex = news.userInteractions.likes.findIndex(like => like.userId === userInfo.userId);
          if (likeIndex !== -1) {
            news.likes -= 1;
            news.userInteractions.likes.splice(likeIndex, 1);
            
            // Remove from user's likes
            const userLikeIndex = user.interactions.likes.findIndex(likeId => String(likeId) === String(news._id));
            if (userLikeIndex !== -1) {
              user.interactions.likes.splice(userLikeIndex, 1);
            }
          }
          break;
          
        case 'undislike':
          // Handle explicit undislike action (same as removing a dislike)
          const dislikeIndex = news.userInteractions.dislikes.findIndex(dislike => dislike.userId === userInfo.userId);
          if (dislikeIndex !== -1) {
            news.dislikes -= 1;
            news.userInteractions.dislikes.splice(dislikeIndex, 1);
            
            // Remove from user's dislikes
            const userDislikeIndex = user.interactions.dislikes.findIndex(dislikeId => String(dislikeId) === String(news._id));
            if (userDislikeIndex !== -1) {
              user.interactions.dislikes.splice(userDislikeIndex, 1);
            }
          }
          break;
          
        case 'comment':
          if (!commentText) {
            return res.status(400).json({ error: 'Comment text is required' });
          }
          news.comments += 1;
          if (!news.userInteractions) {
            news.userInteractions = { likes: [], dislikes: [], comments: [] };
          }
          news.userInteractions.comments.push({
            userId: userInfo.userId,
            userName: userInfo.userName,
            userEmail: userInfo.userEmail,
            comment: commentText
          });
          
          // Add to user's interactions
          user.interactions.comments.push({
            newsId: news._id,
            comment: commentText,
            timestamp: new Date()
          });
          break;
      }
      
      // Save both the updated news item and user
      await Promise.all([news.save(), user.save()]);
    } else {
      // Use in-memory storage
      const newsData = req.app.locals.newsData || [];
      const newsIndex = newsData.findIndex(newsItem => newsItem._id === id);
      
      if (newsIndex === -1) {
        return res.status(404).json({ error: 'News not found' });
      }
      
      // For in-memory storage, we'll just update the counts
      // Note: In-memory storage doesn't track individual user interactions,
      // so we can't properly handle vote changes in this mode
      switch (action) {
        case 'like':
        case 'unlike':
          // Simple implementation for in-memory storage - just increment/decrement likes
          // In a real implementation, you would need to track user interactions
          if (action === 'like') {
            newsData[newsIndex].likes += 1;
          } else {
            newsData[newsIndex].likes = Math.max(0, newsData[newsIndex].likes - 1);
          }
          break;
        case 'dislike':
        case 'undislike':
          // Simple implementation for in-memory storage - just increment/decrement dislikes
          // In a real implementation, you would need to track user interactions
          if (action === 'dislike') {
            newsData[newsIndex].dislikes += 1;
          } else {
            newsData[newsIndex].dislikes = Math.max(0, newsData[newsIndex].dislikes - 1);
          }
          break;
        case 'comment':
          if (!commentText) {
            return res.status(400).json({ error: 'Comment text is required' });
          }
          newsData[newsIndex].comments += 1;
          break;
      }
      
      // Update the news data in app locals
      req.app.locals.newsData = newsData;
      news = newsData[newsIndex];
    }
    
    // Return the updated news item
    const transformedNews = {
      id: news._id,
      title: news.title,
      content: news.content,
      imageUrl: news.thumbnailUrl || news.mediaUrl || news.imageUrl || '/images/placeholder.png',
      mediaUrl: news.mediaUrl || news.imageUrl || '/images/placeholder.png',
      mediaType: news.mediaType || 'image',
      category: news.category,
      location: news.location,
      publishedAt: news.publishedAt,
      likes: news.likes,
      dislikes: news.dislikes,
      comments: news.comments,
      author: news.author,
      isRead: news.isRead || false,
      // Include user interaction details
      userLikes: news.userInteractions?.likes || [],
      userDislikes: news.userInteractions?.dislikes || [],
      userComments: news.userInteractions?.comments || []
    };
    
    res.json(transformedNews);
  } catch (error) {
    console.error('Error processing interaction:', error);
    res.status(500).json({ error: 'Error processing interaction' });
  }
});

// New endpoint to get user profile data
router.post('/api/public/user/profile', async (req, res) => {
  try {
    const { userId, userToken } = req.body;
    
    // Verify authentication token
    let userInfo = null;
    try {
      // Create a mock request object
      const mockReq = { body: { userId, userToken } };
      
      // Create a promise to handle the async middleware
      await new Promise((resolve, reject) => {
        // Call the verifyGoogleToken middleware
        req.app.locals.verifyGoogleToken(mockReq, null, (err) => {
          if (err) {
            reject(err);
          } else {
            resolve();
          }
        });
      });
      
      // If verification is successful, extract user info
      const User = require('../models/User');
      const user = await User.findById(userId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // For Google users, extract info from the token
      if (user.googleId) {
        const client = req.app.locals.googleAuthClient;
        const ticket = await client.verifyIdToken({
          idToken: userToken,
          audience: process.env.GOOGLE_CLIENT_ID,
        });
        
        const payload = ticket.getPayload();
        userInfo = {
          userId: payload['sub'],
          userName: payload['name'] || 'User',
          userEmail: payload['email'] || 'user@example.com',
          photoUrl: payload['picture'] || null
        };
        
        // Update user info in case it changed
        user.displayName = userInfo.userName;
        user.email = userInfo.userEmail;
        user.photoUrl = userInfo.photoUrl;
        user.lastLogin = new Date();
        await user.save();
      } 
      // For mobile users, use the user data from database
      else if (user.mobileNumber) {
        userInfo = {
          userId: user._id,
          userName: user.displayName,
          userEmail: user.email,
          photoUrl: user.photoUrl
        };
        
        // Update last login time
        user.lastLogin = new Date();
        await user.save();
      }
    } catch (authError) {
      return res.status(401).json({ error: authError.message || 'Authentication required' });
    }
    
    // Check if MongoDB is connected by trying to access the connection
    const isConnectedToMongoDB = mongoose.connection.readyState === 1;
    
    let user = null;
    if (isConnectedToMongoDB) {
      // Find or create user in database
      const User = require('../models/User');
      user = await User.findById(userInfo.userId) || await User.findById(userId);
      
      if (!user) {
        user = new User({
          googleId: userInfo.userId,
          displayName: userInfo.userName,
          email: userInfo.userEmail,
          photoUrl: userInfo.photoUrl
        });
        await user.save();
      } else {
        // Update user info in case it changed
        user.displayName = userInfo.userName;
        user.email = userInfo.userEmail;
        user.photoUrl = userInfo.photoUrl;
        user.lastLogin = new Date();
        await user.save();
      }
      
      // Populate user interactions with news data
      await user.populate([
        { path: 'interactions.likes', select: 'title category publishedAt' },
        { path: 'interactions.dislikes', select: 'title category publishedAt' },
        { 
          path: 'interactions.comments.newsId', 
          select: 'title publishedAt category'
        }
      ]);
    }
    
    // Return user profile data
    const userProfile = {
      userId: user ? user._id : userInfo.userId,
      displayName: user ? user.displayName : userInfo.userName,
      email: user ? user.email : userInfo.userEmail,
      mobileNumber: user ? user.mobileNumber : null,
      photoUrl: user ? user.photoUrl : userInfo.photoUrl,
      createdAt: user ? user.createdAt : new Date(),
      lastLogin: user ? user.lastLogin : new Date(),
      stats: {
        likes: user ? user.interactions.likes.length : 0,
        dislikes: user ? user.interactions.dislikes.length : 0,
        comments: user ? user.interactions.comments.length : 0
      },
      interactions: user ? {
        likes: user.interactions.likes.map(news => ({
          id: news._id,
          title: news.title,
          category: news.category,
          publishedAt: news.publishedAt
        })),
        dislikes: user.interactions.dislikes.map(news => ({
          id: news._id,
          title: news.title,
          category: news.category,
          publishedAt: news.publishedAt
        })),
        comments: user.interactions.comments.map(comment => {
          // Handle cases where newsId might not be populated
          if (comment.newsId && typeof comment.newsId === 'object') {
            return {
              newsId: comment.newsId._id,
              newsTitle: comment.newsId.title,
              comment: comment.comment,
              timestamp: comment.timestamp
            };
          } else {
            // If newsId is not populated, return basic info
            return {
              newsId: comment.newsId,
              newsTitle: 'Unknown News',
              comment: comment.comment,
              timestamp: comment.timestamp
            };
          }
        })

      } : {
        likes: [],
        dislikes: [],
        comments: []
      }
    };
    
    res.json(userProfile);
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ error: 'Error fetching user profile' });
  }
});

// Public API endpoint for fetching locations (no authentication required)
router.get('/api/public/locations', async (req, res) => {
  try {
    // Check if MongoDB is connected
    const isConnectedToMongoDB = req.app.locals.isConnectedToMongoDB;
    
    if (isConnectedToMongoDB) {
      // Fetch all locations from MongoDB
      const locations = await Location.find().sort({ name: 1 });
      
      // Calculate news count for each location
      const locationsWithNewsCount = await Promise.all(locations.map(async (location) => {
        const newsCount = await News.countDocuments({ location: location.name });
        return {
          ...location.toObject(),
          newsCount
        };
      }));
      
      res.json(locationsWithNewsCount);
    } else {
      // Use in-memory storage
      const locations = req.app.locals.locationData || [];
      
      // Calculate news count for each location
      const newsData = req.app.locals.newsData || [];
      const locationsWithNewsCount = locations.map(location => {
        const newsCount = newsData.filter(news => news.location === location.name).length;
        return {
          ...location,
          newsCount
        };
      });
      
      res.json(locationsWithNewsCount);
    }
  } catch (error) {
    console.error('Error fetching public locations:', error);
    res.status(500).json({ error: 'Error fetching locations' });
  }
});

// Public API endpoint for fetching active ads (no authentication required)
router.get('/api/public/ads', async (req, res) => {
  try {
    // Check if MongoDB is connected
    const isConnectedToMongoDB = mongoose.connection.readyState === 1;
    
    if (isConnectedToMongoDB) {
      // Fetch all active ads from MongoDB
      const ads = await Ad.find({ isActive: true }).sort({ createdAt: -1 });
      
      // Transform data for Flutter app
      const transformedAds = ads.map(ad => {
        const adObj = ad.toObject ? ad.toObject() : ad;
        return {
          id: adObj._id,
          title: adObj.title,
          content: adObj.content,
          imageUrl: adObj.imageUrl || (adObj.imageUrls && adObj.imageUrls.length > 0 ? adObj.imageUrls[0] : '/images/placeholder.png'),
          imageUrls: adObj.imageUrls || (adObj.imageUrl ? [adObj.imageUrl] : []),
          linkUrl: adObj.linkUrl,
          positionInterval: adObj.positionInterval || 3,
          // Intelligent ad fields
          maxViewsPerDay: adObj.maxViewsPerDay || 3,
          cooldownPeriodHours: adObj.cooldownPeriodHours || 24,
          frequencyControlEnabled: adObj.frequencyControlEnabled !== undefined ? adObj.frequencyControlEnabled : true,
          userBehaviorTrackingEnabled: adObj.userBehaviorTrackingEnabled !== undefined ? adObj.userBehaviorTrackingEnabled : true,
          // AdMob fields
          useAdMob: adObj.useAdMob || false,
          adMobAppId: adObj.adMobAppId,
          adMobUnitId: adObj.adMobUnitId,
          createdAt: adObj.createdAt
        };
      });
      
      res.json(transformedAds);
    } else {
      // Use in-memory storage
      const adsData = req.app.locals.adsData || [];
      const activeAds = adsData.filter(ad => ad.isActive !== false)
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      
      // Transform data for Flutter app
      const transformedAds = activeAds.map(ad => {
        return {
          id: ad._id,
          title: ad.title,
          content: ad.content,
          imageUrl: ad.imageUrl || (ad.imageUrls && ad.imageUrls.length > 0 ? ad.imageUrls[0] : '/images/placeholder.png'),
          imageUrls: ad.imageUrls || (ad.imageUrl ? [ad.imageUrl] : []),
          linkUrl: ad.linkUrl,
          positionInterval: ad.positionInterval || 3,
          // Intelligent ad fields
          maxViewsPerDay: ad.maxViewsPerDay || 3,
          cooldownPeriodHours: ad.cooldownPeriodHours || 24,
          frequencyControlEnabled: ad.frequencyControlEnabled !== undefined ? ad.frequencyControlEnabled : true,
          userBehaviorTrackingEnabled: ad.userBehaviorTrackingEnabled !== undefined ? ad.userBehaviorTrackingEnabled : true,
          // AdMob fields
          useAdMob: ad.useAdMob || false,
          adMobAppId: ad.adMobAppId,
          adMobUnitId: ad.adMobUnitId,
          createdAt: ad.createdAt
        };
      });
      
      res.json(transformedAds);
    }
  } catch (error) {
    console.error('Error fetching public ads:', error);
    res.status(500).json({ error: 'Error fetching ads' });
  }
});

// Public API endpoint for ad interactions (no authentication required)
router.post('/api/public/ads/:id/interaction', async (req, res) => {
  try {
    const { id } = req.params;
    const { adTitle, interactionType, viewDurationSeconds } = req.body;
    
    // Check if MongoDB is connected
    const isConnectedToMongoDB = mongoose.connection.readyState === 1;
    
    if (isConnectedToMongoDB) {
      // Import AdAnalytics model
      const AdAnalytics = require('../models/AdAnalytics');
      
      // Find or create analytics record for this ad
      let adAnalytics = await AdAnalytics.findOne({ adId: id });
      
      if (!adAnalytics) {
        adAnalytics = new AdAnalytics({
          adId: id,
          adTitle: adTitle || 'Unknown Ad'
        });
      }
      
      // Update analytics based on interaction type
      if (interactionType === 'view') {
        adAnalytics.impressions += 1;
        adAnalytics.uniqueViews += 1; // Simplified - in reality, we'd track unique users
        
        if (viewDurationSeconds) {
          // Update average view duration (simplified calculation)
          const totalViewTime = (adAnalytics.avgViewDurationSeconds * (adAnalytics.impressions - 1)) + viewDurationSeconds;
          adAnalytics.avgViewDurationSeconds = totalViewTime / adAnalytics.impressions;
        }
      } else if (interactionType === 'click') {
        adAnalytics.clicks += 1;
      }
      
      // Update CTR
      adAnalytics.ctr = adAnalytics.impressions > 0 ? (adAnalytics.clicks / adAnalytics.impressions) * 100 : 0;
      
      // Update timestamps
      adAnalytics.updatedAt = new Date();
      
      // Save the analytics data
      await adAnalytics.save();
      
      res.json({ message: 'Ad interaction recorded successfully' });
    } else {
      // For in-memory mode, just log the interaction
      console.log(`Ad interaction recorded - ID: ${id}, Type: ${interactionType}, Duration: ${viewDurationSeconds}`);
      res.json({ message: 'Ad interaction recorded successfully (in-memory mode)' });
    }
  } catch (error) {
    console.error('Error recording ad interaction:', error);
    res.status(500).json({ error: 'Error recording ad interaction' });
  }
});

// Public API endpoint for reporting news (no authentication required for now)
router.post('/api/public/news/:id/report', async (req, res) => {
  try {
    const { id } = req.params;
    let { reason, description, userId, userEmail, userName, mobileNumber } = req.body;
    
    // Validate input
    if (!reason) {
      return res.status(400).json({ 
        success: false, 
        message: 'Reason is required' 
      });
    }
    
    // Check if MongoDB is connected
    const isConnectedToMongoDB = req.app.locals.isConnectedToMongoDB;
    
    if (isConnectedToMongoDB) {
      // Check if news exists
      const news = await News.findById(id);
      if (!news) {
        return res.status(404).json({ 
          success: false, 
          message: 'News not found' 
        });
      }
      
      // If we have a userId, try to get the most current user information
      if (userId && userId !== 'anonymous') {
        try {
          const User = require('../models/User');
          const user = await User.findById(userId);
          
          if (user) {
            // Update user information with the most current data from the database
            userName = user.displayName;
            // For mobile users, use the mobileNumber field; for others, use email
            userEmail = user.mobileNumber || user.email;
            // Also get mobile number if available
            mobileNumber = user.mobileNumber || mobileNumber;
          }
        } catch (userError) {
          console.error('Error fetching user data:', userError);
          // Continue with provided data if user lookup fails
        }
      }
      
      // Create report
      const report = new Report({
        newsId: id,
        userId: userId || 'anonymous',
        userEmail: userEmail || '',
        userName: userName || 'Anonymous',
        reason,
        description,
        mobileNumber // Store mobile number explicitly
      });
      
      await report.save();
      
      res.status(201).json({ 
        success: true, 
        message: 'Report submitted successfully',
        report 
      });
    } else {
      // For in-memory storage, we'll just log the report
      console.log(`Report submitted for news ${id}: ${reason}`);
      res.status(201).json({ 
        success: true, 
        message: 'Report submitted successfully (in-memory mode)' 
      });
    }
  } catch (error) {
    console.error('Error submitting report:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error submitting report',
      error: error.message 
    });
  }
});

// New endpoint for mobile number registration
router.post('/api/public/auth/mobile/register', async (req, res) => {
  try {
    const { mobileNumber, name } = req.body;
    
    // Validate input
    if (!mobileNumber || !name) {
      return res.status(400).json({ error: 'Mobile number and name are required' });
    }
    
    // Check if MongoDB is connected
    const isConnectedToMongoDB = mongoose.connection.readyState === 1;
    
    if (!isConnectedToMongoDB) {
      return res.status(500).json({ error: 'Database not available' });
    }
    
    // Check if user already exists with this mobile number
    let user = await User.findOne({ mobileNumber });
    
    if (user) {
      return res.status(400).json({ error: 'User with this mobile number already exists' });
    }
    
    // Create new user
    user = new User({
      mobileNumber,
      displayName: name,
      email: `${mobileNumber}@mobile.user`, // Generate a placeholder email
      photoUrl: null
    });
    
    await user.save();
    
    // Return user data with a simple token (in a real app, you'd use JWT)
    const userData = {
      userId: user._id,
      mobileNumber: user.mobileNumber,
      displayName: user.displayName,
      email: user.email,
      photoUrl: user.photoUrl,
      token: user._id // Simple token, in production use JWT
    };
    
    res.status(201).json(userData);
  } catch (error) {
    console.error('Error registering mobile user:', error);
    res.status(500).json({ error: 'Error registering user' });
  }
});

// New endpoint for mobile number login
router.post('/api/public/auth/mobile/login', async (req, res) => {
  try {
    const { mobileNumber } = req.body;
    
    // Validate input
    if (!mobileNumber) {
      return res.status(400).json({ error: 'Mobile number is required' });
    }
    
    // Check if MongoDB is connected
    const isConnectedToMongoDB = mongoose.connection.readyState === 1;
    
    if (!isConnectedToMongoDB) {
      return res.status(500).json({ error: 'Database not available' });
    }
    
    // Find user by mobile number
    const user = await User.findOne({ mobileNumber });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found. Please register first.' });
    }
    
    // Update last login time
    user.lastLogin = new Date();
    await user.save();
    
    // Return user data with a simple token (in a real app, you'd use JWT)
    const userData = {
      userId: user._id,
      mobileNumber: user.mobileNumber,
      displayName: user.displayName,
      email: user.email,
      photoUrl: user.photoUrl,
      token: user._id // Simple token, in production use JWT
    };
    
    res.json(userData);
  } catch (error) {
    console.error('Error logging in mobile user:', error);
    res.status(500).json({ error: 'Error logging in' });
  }
});

module.exports = router;