const express = require('express');
const router = express.Router();
const categoryController = require('../controllers/categoryController');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Create uploads directory if it doesn't exist
    const uploadDir = path.join(__dirname, '..', 'public', 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    // Generate unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'category-' + uniqueSuffix + path.extname(file.originalname));
  }
});

// Create upload middleware with specific field name
const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: function (req, file, cb) {
    // Accept only image files
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'), false);
    }
  }
});

// Get categories page
router.get('/', categoryController.getAllCategories);

// API Routes for categories
router.get('/api/categories', categoryController.getCategoriesWithCount);
router.get('/api/categories/stats', categoryController.getCategoryStats);
router.get('/api/categories/:id', categoryController.getCategoryById);
router.post('/api/categories', upload.single('image'), categoryController.createCategory);
router.put('/api/categories/:id', upload.single('image'), categoryController.updateCategory);
router.delete('/api/categories/:id', categoryController.deleteCategory);
router.patch('/api/categories/:id/toggle', categoryController.toggleCategoryStatus);

module.exports = router;